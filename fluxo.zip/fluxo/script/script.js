

 $width = $(window).width();
 if($width< 992){
    $('.navbar .dropdown').click(function() {
        $(this).find('.dropdown-menu').fadeIn();
      }, function() {
        $(this).find('.dropdown-menu').fadeOut()
      });
 }
 else{
    $('.navbar .dropdown').hover(function() {
        $(this).find('.dropdown-menu').first().stop(true, true).delay(150).fadeIn();
      }, function() {
        $(this).find('.dropdown-menu').first().stop(true, true).delay(100).fadeOut()
      });
 }
 console.log($width); 